# vercel_party_qr_reader
