
```

[mac]
python3 -m venv venv
source venv/bin/activate
python app.py

[windows]
python -m venv venv
venv\Scripts\activate
python app.py

http://127.0.0.1:5000

git init
git remote add origin https://github.com/tztechno/vercel_flask_party_qr.git
git pull origin master 
git add .
git commit -m "2024-10-24"
git push -u origin master
git push -f origin master

```
